# SIGA — Aula 4 — UML Aplicada a Padrões

Projeto-base para a atividade prática da Aula 4 de Técnicas de Programação II.

## Objetivo

Construir:
- diagrama de classes UML;
- diagrama de sequência para o cálculo da mensalidade;
- modelagem das entidades Pessoa, Aluno, Professor, Turma, Disciplina e Matricula;
- interface Desconto e suas implementações.

## Organização

- `diagramas/diagrama-classes.mmd` — base do diagrama de classes.
- `diagramas/diagrama-sequencia.mmd` — base do diagrama de sequência.
- `src/` — reservado para o código Java das entidades e serviços, caso solicitado.

## Como usar

1. Abra os arquivos `.mmd` no Mermaid.
2. Complete os atributos, métodos, relacionamentos e multiplicidades de acordo com o que foi trabalhado em aula.
3. Gere os diagramas e salve as evidências exigidas pelo professor.
4. Se houver código Java, mantenha um arquivo `.java` por classe pública e use Java 17 ou superior.

## Observação acadêmica

O enunciado da atividade informa que o uso de assistentes de IA para gerar o código é proibido por padrão, salvo autorização expressa da aula. Este repositório é, portanto, um material-base para estudo e preenchimento pelo estudante.

Fonte: Atividade Prática — Aula 4, Técnicas de Programação II.
